#!/bin/bash
clear
echo ""
echo " The Kodi MYSQL Database User Creation Script Part Of The M.O.K.E Toolkit"
echo " By Mark Gillibrand"
echo " https://github.com/y700/M.O.K.E-Toolkit"
echo ""
echo " Please Note That This work is licensed under the Creative Commons Attribution-ShareAlike 4.0 International License."
echo " To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/4.0/"
echo ""
read -n 1 -r -s -p $' Press enter to continue...\n'
echo ""
clear
echo ""
echo " Welcome To The Kodi MYSQL Database User Account Creation Script Part Of The M.O.K.E Toolkit" 
echo ""
echo " This Script Needs To Be Run As A Sudo User Otherwise You Will Get An Acess Denied Error"
echo ""
echo " This Script Automates The Process Of Kodi MYSQL Database  Account Creation"
echo ""
# get user input for username and Password
echo ""
read -p " Enter The Password For The Root MYSQL User Account: "  ruser
echo ""
read -p " Enter The User Name For The User Account You Wish To Create: "  user
echo ""
read -p " Enter The Password For The User Account You Wish To Create: "  pass

# log into the local mysql installation and create the user account with the username and password specified above
mysql -u root -p$ruser <<MYSQL_SCRIPT
CREATE USER '$user'@'%' IDENTIFIED WITH mysql_native_password BY '$pass' ;
GRANT ALL ON *. * TO '$user'@'%';
FLUSH PRIVILEGES;
MYSQL_SCRIPT
echo ""
echo " Success The User Account $user Has Been Created! "
echo ""
echo " Thanks For Useing The Kodi Mysql Database User Creation Script Part Of The M.O.K.E Toolkit"

