#!/bin/bash
clear
echo ""
echo " The Mysql List Users Script Part Of The M.O.K.E Toolkit"
echo " By Mark Gillibrand"
echo " https://github.com/y700/M.O.K.E-Toolkit"
echo ""
echo " Please Note That This work is licensed under the Creative Commons Attribution-ShareAlike 4.0 International License."
echo " To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/4.0/"
echo ""
read -n 1 -r -s -p $' Press enter to continue...\n'
clear
echo ""
echo " Welcome To The MYSQL List Users Script Part Of The M.O.K.E Toolkit"
echo ""
echo " This Script Needs To Be Run As A Sudo User Otherwise You Will Get An Acess Denied Error"
echo ""
echo " This Script Will Display All MYSQL User Accounts"
echo ""
#grab the MYSQL ROOT USER Account Password
read -p " Enter The Password For The Root MYSQL User Account: "  ruser
echo ""
# log into the local mysql installation and list all users
mysql -u root -p$ruser <<MY_QUERY
select host, user from mysql.user;
MY_QUERY
echo ""
echo ""
echo " Thanks For Useing The List MYSQL User's Script Part Of The M.O.K.E Toolkit"

