How to run

1. Make the script executable, open a Terminal and change to the directory of this script if its in your home directory use cd /home/your-username/M.O.K.E-Toolkit-1.0

2. Type sudo chmod 700 owncloud-database-setup.sh

3. Run the script sudo ./owncloud-database-setup.sh 
