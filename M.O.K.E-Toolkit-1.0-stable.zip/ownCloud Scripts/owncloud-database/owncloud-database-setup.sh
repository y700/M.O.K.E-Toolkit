#!/bin/bash
clear
echo ""
echo " The ownCloud Mysql User Account and Database Creation Script Part Of The M.O.K.E Toolkit"
echo " By Mark Gillibrand"
echo " https://github.com/y700/M.O.K.E-Toolkit"
echo ""
echo " Please Note That This work is licensed under the Creative Commons Attribution-ShareAlike 4.0 International License."
echo " To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/4.0/"
echo ""
read -n 1 -r -s -p $' Press enter to continue...\n'
clear
echo " Welcome To The ownCloud Mysql User Account and Database Creation Script Part Of The M.O.K.E Toolkit"
echo ""
echo " This Script Needs To Be Run As A Sudo User Otherwise You Will Get An Acess Denied Error"
echo ""
echo " This Script Automates The Process Of The ownCloud User Account And Database Creation"
# get user input for username password and Database name
echo ""
read -p " Enter The Password For The Root MYSQL User Account: "  ruser
echo ""
read -p " Enter The User Name For The ownCloud Database User Account You Wish To Create: "  user
echo ""
read -p " Enter The Password For The ownCloud Database User Account You Wish To Create: "  pass
echo ""
read -p " Enter The Name you wish to use for your ownCloud Database: " dbname
echo ""
# log into the local mysql installation and create the ownCloud user and Database with the credentials specified above

mysql -u root -p$ruser <<MYSQL_SCRIPT
CREATE USER '$user'@'localhost' IDENTIFIED WITH mysql_native_password BY '$pass' ;
CREATE DATABASE $dbname ; 
GRANT ALL PRIVILEGES ON $dbname.* TO '$user'@'localhost' WITH GRANT OPTION ;
FLUSH PRIVILEGES ;
MYSQL_SCRIPT

echo ""
echo " Success The User Account $user Has Been Created!"
echo ""
echo " Success The Database $dbname Has Been Created!"
echo ""
echo " Thanks For Useing The ownCloud Mysql User and Database Creation Script Part Of The M.O.K.E Toolkit"
